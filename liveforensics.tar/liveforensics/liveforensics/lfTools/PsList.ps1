#
# PsList.ps1
#
function Get-PsList {
	$result = Get-Process | Select Id, ProcessName, Description, StartTime, Path
	Write-Output $result
}