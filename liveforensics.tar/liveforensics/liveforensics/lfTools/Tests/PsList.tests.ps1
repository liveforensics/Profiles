﻿Import-Module liveforensics -Force

InModuleScope 'lfTools' {
	Describe "PsList" {
		Context "Exists" {
			It "Runs" {
				Mock Get-Process { $null}
				$result = Get-PsList
				Write-Host $result
				$result | Should BeNullOrEmpty
			}
		}
	}
}