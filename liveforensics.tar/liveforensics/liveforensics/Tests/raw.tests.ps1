﻿Import-Module 'liveforensics' -Force

InModuleScope 'raw' {
	Describe "raw" {
		Context "Exists" {
			It "Runs" {
				$true | Should be $true
			}
		}
	}

	Describe "Testing process lister" {
		Context "Process List is available" {
			It "Runs" {
				Mock Get-Process { return 'aint no such thing'}
				$ans = Get-PsList
				Write-Host 'processes: ' $ans
				$true | Should be $true
			}
		}
	}
}