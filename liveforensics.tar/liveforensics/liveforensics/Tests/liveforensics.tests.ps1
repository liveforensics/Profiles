Import-Module 'liveforensics' -Force

Describe "Get-Function" {
	Context "Function Exists" {
		It "Should Return" {
			$true | Should Be $true
		}
	}
}