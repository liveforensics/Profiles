#
# raw.psm1
#


function Get-PsList {
	$result = Get-Process | Select Id, ProcessName, Description, StartTime, Path
	return $result
}