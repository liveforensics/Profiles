<#
	Read-Sector
#>
Get-ChildItem $PSScriptRoot | ? { $_.PSIsContainer -and ($_.Name -ne 'Tests') } | % { Import-Module $_.FullName -DisableNameChecking }

#function Read-SectorX
#{
#	[CmdletBinding()]
#	param(
#		[Parameter(Mandatory, ValueFromPipeline)]
#		[string]$Param, [int]$sector)

#	Write-Host $Param
#	Write-Host $sector

#}

