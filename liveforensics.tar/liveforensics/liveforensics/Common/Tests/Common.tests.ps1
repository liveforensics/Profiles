﻿Describe "Common" {
	Context "Exists" {
		It "Runs" {
			$true | Should Be $true
		}
	}
}