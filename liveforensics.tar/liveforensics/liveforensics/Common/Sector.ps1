#
# Sector.ps1
#
function Write-Sector
{
	<#
	.SYNOPSIS
		A brief description of the function or script. This keyword can be used
		only once in each topic.
	
	.DESCRIPTION
		A detailed description of the function or script. This keyword can be
		used only once in each topic.
	
	.PARAMETER Name
		The description of a parameter. Add a .PARAMETER keyword for
		each parameter in the function or script syntax.
		
		Type the parameter name on the same line as the .PARAMETER keyword.
		Type the parameter description on the lines following the .PARAMETER
		keyword. Windows PowerShell interprets all text between the .PARAMETER
		line and the next keyword or the end of the comment block as part of
		the parameter description. The description can include paragraph breaks.
		
		The Parameter keywords can appear in any order in the comment block, but
		the function or script syntax determines the order in which the parameters
		(and their descriptions) appear in help topic. To change the order,
										change the syntax.
		
		You can also specify a parameter description by placing a comment in the
		function or script syntax immediately before the parameter variable name.
		If you use both a syntax comment and a Parameter keyword, the description
		associated with the Parameter keyword is used, and the syntax comment is
		ignored.
	
	.EXAMPLE
		PS> Write-Sector -Name 'MYVM'
		
		This example retrieves the virtual machine with the name of MYVM from whatever virtualization system
		it's supposed to work with.
	
	.INPUTS
		None.
	
	.OUTPUTS
		System.Management.Automation.PSCustomObject
	
	.NOTES
		Requirements: This requires
	
	.LINK
		http://www.google.com
	
	#>

	[CmdletBinding()]
	param(
		[Parameter(Mandatory = $True, ValueFromPipeline)]
		[int]$start_sector, 
		[Parameter(Mandatory = $True, ValueFromPipeline)]
		[Byte[]]$sector_data, 
		[Parameter(Mandatory = $False, ValueFromPipeline)]
		[ValidateRange(1,16)]
		[int]$count=1)

	$linecounter = 0 # Offset from beginning of file in hex.
	$placeholder = "." # What to print when byte is not a letter or digit.
	$width = 16
	$NoOffset = $False
	$NoText = $False

	$length = $sector_data.Count
	Write-Host 'Length: ' $length
	#Write-Host $start_sector
	$sector_data | 
	foreach-object
	{
		$paddedhex = $text = $null
		$bytes = $_ # Array of [Byte] objects that is $width items in length.
		foreach ($byte in $bytes)`
		{
			$byteinhex = [String]::Format("{0:X}", $byte) # Convert byte to hex.
			$paddedhex += $byteinhex.PadLeft(2,"0") + " " # Pad with two zeros.
		}
		# Total bytes unlikely to be evenly divisible by $width, so fix last line.
		# Hex output width is '$width * 3' because of the extra spaces.
		if ($paddedhex.length -lt $width * 3)
		{ 
			$paddedhex = $paddedhex.PadRight($width * 3," ") 
		}
		foreach ($byte in $bytes)`
		{
			if ( [Char]::IsLetterOrDigit($byte) -or	[Char]::IsPunctuation($byte) -or [Char]::IsSymbol($byte) )
			{ 
				$text += [Char] $byte 
			}
			else
			{ 
				$text += $placeholder 
			}
		}
		$offsettext = [String]::Format("{0:X}", $linecounter) # Linecounter in hex too.
		$offsettext = $offsettext.PadLeft(8,"0") + "h:" # Pad linecounter with left zeros.
		$linecounter += $width # Increment linecounter.
		if (-not $NoOffset) 
		{ 
			$paddedhex = "$offsettext $paddedhex" 
		}
		if (-not $NoText) 
		{ 
			$paddedhex = $paddedhex + $text 
		}
		$paddedhex
	}
	Write-Host $count
}

function Read-Sector
{
	[CmdletBinding()]
	param(
		[Parameter(Mandatory, ValueFromPipeline)]
		[string]$Param, [int]$sector)

	Write-Host $Param
	Write-Host $sector

}