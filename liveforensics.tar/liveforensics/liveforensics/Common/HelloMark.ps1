#
# HelloMark.ps1
#
function Get-HelloMark {
	Write-Output 'hello mark'
}