#
# HelloMark.ps1
#
function Get-HelloMark {
	Write-Output 'hello mark'
}

function Get-Anything {
	Write-Output 'ANYTHING'
}
