## Open the XML file to go over namespace, elements and MAML schema
ise 'C:\Dropbox\Business Projects\Courses\Pluralsight\Course Authoring\Active Courses\building-advanced-powershell-functions-and-modules\building-advanced-powershell-functions-and-modules-m7\Demos\XML Help\Module Help\MyModule.psm1-help.xml'

## Tools to help
start https://www.sapien.com/software/powershell_helpwriter
start http://cmdletdesigner.codeplex.com
start http://blogs.msdn.com/b/powershell/archive/2007/05/08/cmdlet-help-editor-tool.aspx